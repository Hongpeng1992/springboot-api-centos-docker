package com.example.demo.rest;

public class ResourceConstants {
	
	public static final String ROOM_RESERVATION_V1="/room/reservations/v1";

}
